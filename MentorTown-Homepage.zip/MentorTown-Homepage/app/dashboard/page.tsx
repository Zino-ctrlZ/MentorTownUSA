'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bar, BarChart, Line, LineChart, Pie, PieChart } from "recharts"
import { ChartContainer } from "@/components/ui/chart"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Bell, CalendarIcon, BookOpen, Users, BarChartIcon } from 'lucide-react'

export default function DashboardPage() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [expandedChart, setExpandedChart] = useState<string | null>(null);

  // Mock data for charts
  const clientData = [
    { name: 'Jan', total: 5 },
    { name: 'Feb', total: 8 },
    { name: 'Mar', total: 12 },
    { name: 'Apr', total: 10 },
    { name: 'May', total: 15 },
  ]

  const performanceData = [
    { name: 'Week 1', performance: 75 },
    { name: 'Week 2', performance: 80 },
    { name: 'Week 3', performance: 85 },
    { name: 'Week 4', performance: 90 },
  ]

  const clientAgeData = [
    { name: '18-24', value: 20 },
    { name: '25-34', value: 35 },
    { name: '35-44', value: 25 },
    { name: '45-54', value: 15 },
    { name: '55+', value: 5 },
  ]

  const careerInterestsData = [
    { name: 'Technology', value: 30 },
    { name: 'Healthcare', value: 25 },
    { name: 'Finance', value: 20 },
    { name: 'Education', value: 15 },
    { name: 'Others', value: 10 },
  ]

  const educationLevelData = [
    { name: 'High School', value: 15 },
    { name: 'Bachelor\'s', value: 40 },
    { name: 'Master\'s', value: 30 },
    { name: 'PhD', value: 10 },
    { name: 'Other', value: 5 },
  ]

  const schoolTypeData = [
    { name: 'Public', value: 55 },
    { name: 'Private', value: 35 },
    { name: 'Online', value: 10 },
  ]

  const extracurricularData = [
    { name: 'Sports', value: 30 },
    { name: 'Arts', value: 20 },
    { name: 'Volunteering', value: 25 },
    { name: 'Tech Clubs', value: 15 },
    { name: 'Others', value: 10 },
  ]

  const notifications = [
    { id: 1, message: 'New client sign-up: Sarah Johnson', time: '2 hours ago' },
    { id: 2, message: 'Course completion: Advanced Mentoring Techniques', time: 'Yesterday' },
    { id: 3, message: 'Upcoming webinar: Effective Goal Setting', time: 'Tomorrow, 2 PM' },
    { id: 4, message: 'Client milestone achieved: John Doe', time: '3 days ago' },
    { id: 5, message: 'New resource added: Career Transition Guide', time: '1 week ago' },
  ]

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <div className="flex items-center space-x-2">
          <Button>
            <Bell className="mr-2 h-4 w-4" />
            Notifications
          </Button>
        </div>
      </div>
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="analytics">Analytics and Reports</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Clients
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">25</div>
                <p className="text-xs text-muted-foreground">
                  +2 from last month
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Upcoming Sessions
                </CardTitle>
                <CalendarIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12</div>
                <p className="text-xs text-muted-foreground">
                  Next 7 days
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Course Enrollments
                </CardTitle>
                <BookOpen className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-muted-foreground">
                  This month
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Goal Progress</CardTitle>
                <BarChartIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">75%</div>
                <Progress value={75} className="mt-2" />
              </CardContent>
            </Card>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>Client Growth</CardTitle>
              </CardHeader>
              <CardContent className="pl-2">
                <ChartContainer
                  config={{
                    total: {
                      label: "Total Clients",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                  className="h-[200px] w-full"
                >
                  <BarChart data={clientData}>
                    <Bar dataKey="total" fill="var(--color-total)" />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>
            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>Upcoming Appointments</CardTitle>
                <CardDescription>
                  Your schedule for the next 7 days
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className="rounded-md border"
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card
              className={`cursor-pointer transition-all duration-300 ${expandedChart === 'clientAge' ? 'col-span-full' : ''}`}
              onClick={() => setExpandedChart(expandedChart === 'clientAge' ? null : 'clientAge')}
            >
              <CardHeader>
                <CardTitle>Client Age Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    value: {
                      label: "Clients",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                  className="h-[200px] w-full"
                >
                  {expandedChart === 'clientAge' ? (
                    <>
                      <BarChart data={clientAgeData}>
                        <Bar dataKey="value" fill="var(--color-value)" />
                      </BarChart>
                      <PieChart data={clientAgeData}>
                        <Pie dataKey="value" nameKey="name" fill="var(--color-value)" label />
                      </PieChart>
                      <LineChart data={clientAgeData}>
                        <Line type="monotone" dataKey="value" stroke="var(--color-value)" />
                      </LineChart>
                    </>
                  ) : (
                    <PieChart data={clientAgeData}>
                      <Pie dataKey="value" nameKey="name" fill="var(--color-value)" label />
                    </PieChart>
                  )}
                </ChartContainer>
              </CardContent>
            </Card>
            <Card
              className={`cursor-pointer transition-all duration-300 ${expandedChart === 'careerInterests' ? 'col-span-full' : ''}`}
              onClick={() => setExpandedChart(expandedChart === 'careerInterests' ? null : 'careerInterests')}
            >
              <CardHeader>
                <CardTitle>Career Interests</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    value: {
                      label: "Clients",
                      color: "hsl(var(--chart-2))",
                    },
                  }}
                  className="h-[200px] w-full"
                >
                  {expandedChart === 'careerInterests' ? (
                    <>
                      <BarChart data={careerInterestsData} layout="vertical">
                        <Bar dataKey="value" fill="var(--color-value)" />
                      </BarChart>
                      <PieChart data={careerInterestsData}>
                        <Pie dataKey="value" nameKey="name" fill="var(--color-value)" label />
                      </PieChart>
                      <LineChart data={careerInterestsData}>
                        <Line type="monotone" dataKey="value" stroke="var(--color-value)" />
                      </LineChart>
                    </>
                  ) : (
                    <BarChart data={careerInterestsData} layout="vertical">
                      <Bar dataKey="value" fill="var(--color-value)" />
                    </BarChart>
                  )}
                </ChartContainer>
              </CardContent>
            </Card>
            <Card
              className={`cursor-pointer transition-all duration-300 ${expandedChart === 'educationLevel' ? 'col-span-full' : ''}`}
              onClick={() => setExpandedChart(expandedChart === 'educationLevel' ? null : 'educationLevel')}
            >
              <CardHeader>
                <CardTitle>Education Level</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    value: {
                      label: "Clients",
                      color: "hsl(var(--chart-3))",
                    },
                  }}
                  className="h-[200px] w-full"
                >
                  {expandedChart === 'educationLevel' ? (
                    <>
                      <BarChart data={educationLevelData}>
                        <Bar dataKey="value" fill="var(--color-value)" />
                      </BarChart>
                      <PieChart data={educationLevelData}>
                        <Pie dataKey="value" nameKey="name" fill="var(--color-value)" label />
                      </PieChart>
                      <LineChart data={educationLevelData}>
                        <Line type="monotone" dataKey="value" stroke="var(--color-value)" />
                      </LineChart>
                    </>
                  ) : (
                    <PieChart data={educationLevelData}>
                      <Pie dataKey="value" nameKey="name" fill="var(--color-value)" label />
                    </PieChart>
                  )}
                </ChartContainer>
              </CardContent>
            </Card>
            <Card
              className={`cursor-pointer transition-all duration-300 ${expandedChart === 'schoolType' ? 'col-span-full' : ''}`}
              onClick={() => setExpandedChart(expandedChart === 'schoolType' ? null : 'schoolType')}
            >
              <CardHeader>
                <CardTitle>School Type</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    value: {
                      label: "Clients",
                      color: "hsl(var(--chart-4))",
                    },
                  }}
                  className="h-[200px] w-full"
                >
                  {expandedChart === 'schoolType' ? (
                    <>
                      <BarChart data={schoolTypeData}>
                        <Bar dataKey="value" fill="var(--color-value)" />
                      </BarChart>
                      <PieChart data={schoolTypeData}>
                        <Pie dataKey="value" nameKey="name" fill="var(--color-value)" label />
                      </PieChart>
                      <LineChart data={schoolTypeData}>
                        <Line type="monotone" dataKey="value" stroke="var(--color-value)" />
                      </LineChart>
                    </>
                  ) : (
                    <PieChart data={schoolTypeData}>
                      <Pie dataKey="value" nameKey="name" fill="var(--color-value)" label />
                    </PieChart>
                  )}
                </ChartContainer>
              </CardContent>
            </Card>
            <Card
              className={`cursor-pointer transition-all duration-300 ${expandedChart === 'extracurricular' ? 'col-span-full' : ''}`}
              onClick={() => setExpandedChart(expandedChart === 'extracurricular' ? null : 'extracurricular')}
            >
              <CardHeader>
                <CardTitle>Extracurricular Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    value: {
                      label: "Clients",
                      color: "hsl(var(--chart-5))",
                    },
                  }}
                  className="h-[200px] w-full"
                >
                  {expandedChart === 'extracurricular' ? (
                    <>
                      <BarChart data={extracurricularData}>
                        <Bar dataKey="value" fill="var(--color-value)" />
                      </BarChart>
                      <PieChart data={extracurricularData}>
                        <Pie dataKey="value" nameKey="name" fill="var(--color-value)" label />
                      </PieChart>
                      <LineChart data={extracurricularData}>
                        <Line type="monotone" dataKey="value" stroke="var(--color-value)" />
                      </LineChart>
                    </>
                  ) : (
                    <BarChart data={extracurricularData}>
                      <Bar dataKey="value" fill="var(--color-value)" />
                    </BarChart>
                  )}
                </ChartContainer>
              </CardContent>
            </Card>
            <Card
              className={`cursor-pointer transition-all duration-300 ${expandedChart === 'performance' ? 'col-span-full' : ''}`}
              onClick={() => setExpandedChart(expandedChart === 'performance' ? null : 'performance')}
            >
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    performance: {
                      label: "Performance",
                      color: "hsl(var(--chart-6))",
                    },
                  }}
                  className="h-[200px] w-full"
                >
                  {expandedChart === 'performance' ? (
                    <>
                      <BarChart data={performanceData}>
                        <Bar dataKey="performance" fill="var(--color-performance)" />
                      </BarChart>
                      <LineChart data={performanceData}>
                        <Line type="monotone" dataKey="performance" stroke="var(--color-performance)" />
                      </LineChart>
                      <PieChart data={performanceData}>
                        <Pie dataKey="performance" nameKey="name" fill="var(--color-performance)" label />
                      </PieChart>
                    </>
                  ) : (
                    <LineChart data={performanceData}>
                      <Line type="monotone" dataKey="performance" stroke="var(--color-performance)" />
                    </LineChart>
                  )}
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Recent Notifications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {notifications.map((notification) => (
                  <div key={notification.id} className="flex items-center">
                    <Bell className="h-4 w-4 mr-2 text-muted-foreground" />
                    <div className="ml-4 space-y-1">
                      <p className="text-sm font-medium leading-none">{notification.message}</p>
                      <p className="text-sm text-muted-foreground">
                        {notification.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Client Interactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {[
                { name: 'Alice Johnson', interaction: 'Session completed', date: '2 hours ago' },
                { name: 'Bob Smith', interaction: 'Goal updated', date: 'Yesterday' },
                { name: 'Carol Williams', interaction: 'New session scheduled', date: '2 days ago' },
              ].map((client, index) => (
                <div key={index} className="flex items-center">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={`/avatars/${index + 1}.png`} alt={client.name} />
                    <AvatarFallback>{client.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div className="ml-4 space-y-1">
                    <p className="text-sm font-medium leading-none">{client.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {client.interaction}
                    </p>
                  </div>
                  <div className="ml-auto font-medium text-sm text-muted-foreground">
                    {client.date}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Quick Access</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4">
            <Button className="w-full justify-start">
              <Users className="mr-2 h-4 w-4" />
              Client Management
            </Button>
            <Button className="w-full justify-start">
              <CalendarIcon className="mr-2 h-4 w-4" />
              Calendar
            </Button>
            <Button className="w-full justify-start">
              <BookOpen className="mr-2 h-4 w-4" />
              Resource Library
            </Button>
            <Button className="w-full justify-start">
              <BarChartIcon className="mr-2 h-4 w-4" />
              Create Course
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

