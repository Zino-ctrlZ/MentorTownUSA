'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { CalendarIcon, ChevronUpIcon, Users, BarChart, BookOpen } from "lucide-react"
import { LineChart, BarChart } from '@/components/ui/chart'

export default function Dashboard() {
  const [progressValue, setProgressValue] = useState(66)

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Welcome back, Sarah!</h1>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-muted-foreground">+2 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sessions This Week</CardTitle>
            <CalendarIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">3 more than last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Client Progress</CardTitle>
            <BarChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{progressValue}%</div>
            <Progress value={progressValue} className="mt-2" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Resources Used</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">35</div>
            <p className="text-xs text-muted-foreground">+5 from last month</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7 mt-6">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Client Progress Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <LineChart
              data={[
                { date: "Jan", progress: 45 },
                { date: "Feb", progress: 52 },
                { date: "Mar", progress: 49 },
                { date: "Apr", progress: 58 },
                { date: "May", progress: 66 },
              ]}
              index="date"
              categories={["progress"]}
              colors={["blue"]}
              valueFormatter={(value) => `${value}%`}
              className="h-[200px]"
            />
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Upcoming Sessions</CardTitle>
            <CardDescription>You have 3 sessions scheduled for today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: "Alice Johnson", time: "10:00 AM", type: "Career Guidance" },
                { name: "Bob Smith", time: "2:00 PM", type: "Resume Review" },
                { name: "Carol Williams", time: "4:30 PM", type: "Interview Prep" },
              ].map((session, index) => (
                <div key={index} className="flex items-center">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={`/avatars/${index + 1}.png`} alt={session.name} />
                    <AvatarFallback>{session.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div className="ml-4 space-y-1">
                    <p className="text-sm font-medium leading-none">{session.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {session.time} - {session.type}
                    </p>
                  </div>
                  <Badge className="ml-auto" variant="outline">{session.type}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7 mt-6">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Client Interactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {[
                { id: 1, name: 'David Brown', interaction: 'Goal achieved', date: '2 hours ago' },
                { id: 2, name: 'Emma Davis', interaction: 'Session feedback', date: 'Yesterday' },
                { id: 3, name: 'Frank Wilson', interaction: 'New milestone set', date: '2 days ago' },
              ].map((client, index) => (
                <div key={index} className="flex items-center">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={`/avatars/${client.id}.png`} alt={client.name} />
                    <AvatarFallback>{client.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div className="ml-4 space-y-1">
                    <p className="text-sm font-medium leading-none">{client.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {client.interaction}
                    </p>
                  </div>
                  <div className="ml-auto font-medium text-sm text-muted-foreground">
                    {client.date}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Resource Usage</CardTitle>
          </CardHeader>
          <CardContent>
            <BarChart
              data={[
                { resource: "Career Guides", usage: 28 },
                { resource: "Assessment Tools", usage: 22 },
                { resource: "Interview Prep", usage: 18 },
                { resource: "Networking Tips", usage: 12 },
              ]}
              index="resource"
              categories={["usage"]}
              colors={["blue"]}
              valueFormatter={(value) => `${value}`}
              className="h-[200px]"
            />
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 flex justify-end">
        <Button asChild>
          <Link href="/client-management">View All Clients</Link>
        </Button>
      </div>
    </div>
  )
}

