import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from 'next/link'

export default function Dashboard() {
  return (
    <div className="grid grid-cols-12 gap-6">
      {/* other components here */}

      <Card className="col-span-4">
        <CardHeader>
          <CardTitle>Recent Client Interactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-8">
            {[
              { id: 1, name: 'Alice Johnson', interaction: 'Session completed', date: '2 hours ago' },
              { id: 2, name: 'Bob Smith', interaction: 'Goal updated', date: 'Yesterday' },
              { id: 3, name: 'Carol Williams', interaction: 'New session scheduled', date: '2 days ago' },
            ].map((client, index) => (
              <div key={index} className="flex items-center">
                <Link href={`/client/${client.id}`} className="flex items-center hover:underline">
                  <div className="flex items-center justify-center h-9 w-9 rounded-full bg-gray-200 text-gray-600 font-semibold text-sm mr-4">
                    {client.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">{client.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {client.interaction}
                    </p>
                  </div>
                </Link>
                <div className="ml-auto font-medium text-sm text-muted-foreground">
                  {client.date}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* other components here */}
    </div>
  );
}

