import Link from 'next/link'

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="bg-white shadow-sm">
          <nav className="container mx-auto px-4 py-3">
            <ul className="flex space-x-4">
              <li><Link href="/" className="text-blue-600 hover:text-blue-800">Home</Link></li>
              <li><Link href="/dashboard" className="text-blue-600 hover:text-blue-800">Dashboard</Link></li>
              <li><Link href="/client-management" className="text-blue-600 hover:text-blue-800">Client Management</Link></li>
            </ul>
          </nav>
        </header>
        {children}
      </body>
    </html>
  )
}

